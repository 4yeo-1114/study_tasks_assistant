import examples.task_proposal_demo as task_proposal_demo
from web.auth import AuthService
from storage.database import Database
from llm.deepseek_api import DeepSeekAPIError
from storage.migration import upgrade_database
from llm.deepseek_tools import ToolCallProposal
from examples.task_proposal_demo import confirm_preview


class FakeProposals:
    def __init__(self):
        self.actions = []

    def confirm(self, user_id, proposal_id):
        self.actions.append(("confirm", user_id, proposal_id))
        return {"task": {"id": 7}}

    def reject(self, user_id, proposal_id):
        self.actions.append(("reject", user_id, proposal_id))
        return {"status": "rejected"}


def test_demo_does_not_write_without_explicit_yes(monkeypatch):
    proposals = FakeProposals()
    preview = {"id": "proposal-id", "title": "学习 Agent", "priority": "high",
               "due_date": None, "expires_at": 1000}
    monkeypatch.setattr("builtins.input", lambda _: "no")
    assert confirm_preview(preview, user_id=3, service=proposals) is None
    assert proposals.actions == [("reject", 3, "proposal-id")]

    monkeypatch.setattr("builtins.input", lambda _: "yes")
    assert confirm_preview(preview, user_id=3, service=proposals) == 7
    assert proposals.actions[-1] == ("confirm", 3, "proposal-id")


def test_demo_reports_provider_error_without_traceback(tmp_path, monkeypatch, capsys):
    url = f"sqlite+pysqlite:///{(tmp_path / 'demo.db').as_posix()}"
    upgrade_database(url)
    database = Database(url)
    try:
        auth = AuthService(database.sessions, "test-secret-key-at-least-32-bytes")
        assert auth.register("alice", "password-123")
    finally:
        database.dispose()

    monkeypatch.setenv("DATABASE_URL", url)
    answers = iter(["alice", "帮我创建复习任务"])
    monkeypatch.setattr("builtins.input", lambda _: next(answers))
    monkeypatch.setattr(task_proposal_demo.getpass, "getpass", lambda _: "password-123")
    monkeypatch.setattr(task_proposal_demo.DeepSeekSettings, "from_env", lambda: object())

    def fail(*args, **kwargs):
        raise DeepSeekAPIError(401, "invalid key")

    monkeypatch.setattr(task_proposal_demo, "propose_task_from_model", fail)
    assert task_proposal_demo.main() == 1
    assert "提案失败: DeepSeek API 返回 HTTP 401" in capsys.readouterr().err


def test_demo_shows_task_count_before_and_after_user_decision(tmp_path, monkeypatch, capsys):
    url = f"sqlite+pysqlite:///{(tmp_path / 'demo.db').as_posix()}"
    upgrade_database(url)
    database = Database(url)
    try:
        auth = AuthService(database.sessions, "test-secret-key-at-least-32-bytes")
        assert auth.register("alice", "password-123")
    finally:
        database.dispose()

    monkeypatch.setenv("DATABASE_URL", url)
    monkeypatch.setattr(task_proposal_demo.getpass, "getpass", lambda _: "password-123")
    monkeypatch.setattr(task_proposal_demo.DeepSeekSettings, "from_env", lambda: object())

    def fake_proposal(question, *, user_id, service, settings):
        return service.propose_from_call(user_id, ToolCallProposal(
            "call-1", "create_task", {"title": "复习 SQL"}
        ))

    monkeypatch.setattr(task_proposal_demo, "propose_task_from_model", fake_proposal)
    answers = iter(["alice", "复习 SQL", "no"])
    monkeypatch.setattr("builtins.input", lambda _: next(answers))
    assert task_proposal_demo.main() == 0
    output = capsys.readouterr().out
    assert "确认前任务数: 0" in output
    assert "结束后任务数: 0" in output

    answers = iter(["alice", "复习 SQL", "yes"])
    assert task_proposal_demo.main() == 0
    output = capsys.readouterr().out
    assert "确认前任务数: 0" in output
    assert "结束后任务数: 1" in output
