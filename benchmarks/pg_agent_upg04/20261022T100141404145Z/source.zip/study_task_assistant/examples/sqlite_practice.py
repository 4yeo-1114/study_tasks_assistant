import os
import sqlite3




db_path = os.path.join(os.path.dirname(__file__), "study_tasks.db")
conn = sqlite3.connect(db_path)
cur = conn.cursor()

cur.execute(
    """
    CREATE TABLE IF NOT EXISTS tasks (
        id INTEGER PRIMARY KEY,
        title TEXT NOT NULL,
        status TEXT DEFAULT 'pending'
    )
    """
)
cur.execute(
    "INSERT INTO tasks (title, status) VALUES (?, ?)",
    ("学习sql", "pending"),
)
cur.execute(
    "INSERT INTO tasks (title) VALUES (?)",
    ("学习sqlite",),
)

cur.execute(
    "UPDATE tasks SET status = ? WHERE id = ?",
    ("completed", 1),
)
cur.execute(
    "DELETE FROM tasks WHERE id = ?",
    (2,),
)
cur.execute(
    "UPDATE tasks SET status = ? WHERE id = ?",
    ("completed", 999),
)

#cur.rowcount 表示上一条sqlite语句影响的行数
print("不存在的 id 影响行数:", cur.rowcount)

cur.execute(
    "INSERT INTO tasks (title) VALUES (?)",
    ('阅读“sql 必知必会”',),
)
cur.execute(
    "INSERT INTO tasks (title) VALUES (?)",
    ('阅读 "SQL 必知必会"',),
)





conn.commit()

print("全部任务:")
for row in cur.execute("SELECT id, title, status FROM tasks ORDER BY id"):
    print(row)

print("id=1:", cur.execute("SELECT id, title, status FROM tasks WHERE id = ?", (1,)).fetchone())
print("id=2:", cur.execute("SELECT id, title, status FROM tasks WHERE id = ?", (2,)).fetchone())
print("id=999:", cur.execute("SELECT id, title, status FROM tasks WHERE id = ?", (999,)).fetchone())
print(cur.execute("SELECT id,title,status FROM tasks WHERE title = ?",('阅读“sql 必知必会”',)).fetchone())
conn.close()
