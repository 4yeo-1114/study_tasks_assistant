from knowledge.rag import DocumentChunk, KeywordRetriever
from knowledge.rag_grounding import answer_with_evidence
from knowledge.retrieval_eval import RetrievalEvalCase, diagnose_grounding_case


CHUNKS = [
    DocumentChunk("proposal.md", 1, "proposal_id 用于防止同一任务提案被重复确认。"),
    DocumentChunk("auth.md", 1, "JWT 用于认证当前用户身份。"),
]


def main() -> None:
    retriever = KeywordRetriever(CHUNKS)

    grounded_case = RetrievalEvalCase(
        "合法引用",
        "proposal_id 有什么作用？",
        ("proposal.md",),
    )
    grounded_results = retriever.search(grounded_case.query)
    grounded = answer_with_evidence(
        grounded_results,
        lambda context: "proposal_id 可以防止重复确认。\n[来源: proposal.md#1]",
    )
    print("合法引用:", diagnose_grounding_case(grounded_case, grounded_results, grounded))

    empty_case = RetrievalEvalCase(
        "无资料拒答",
        "数据库连接池如何自动扩容？",
        (),
        expected_empty=True,
    )
    empty_results = retriever.search(empty_case.query)
    empty = answer_with_evidence(
        empty_results,
        lambda context: "这段生成器不应该被调用",
    )
    print("无资料:", diagnose_grounding_case(empty_case, empty_results, empty))

    fake_case = RetrievalEvalCase(
        "伪造引用",
        "proposal_id 有什么作用？",
        ("proposal.md",),
    )
    fake_results = retriever.search(fake_case.query)
    fake = answer_with_evidence(
        fake_results,
        lambda context: "可以防止重复确认。\n[来源: fake.md#99]",
    )
    print("伪造引用:", diagnose_grounding_case(fake_case, fake_results, fake))


if __name__ == "__main__":
    main()
